
const About = () => {
    return(
        <>
            <div className="about">
                <h1>Paul Online Shopping in Nigeria - Best Shopping Site</h1>
                <p>Paul is Nigeria’s number one online Shopping destination.We pride ourselves in having everything you could possibly need for life and living at the best prices than anywhere else. Our access to Original Equipment Manufacturers and premium sellers gives us a wide range of products at very low prices. Some of our popular categories include electronics, mobile phones, computers, fashion, beauty products, home and kitchen, Building and construction materials and a whole lot more from premium brands. Some of our other categories include Food and drinks, automotive and industrial, books, musical equipment, babies and kids items, sports and fitness, to mention a few. </p>
            </div>
        </>
    )
}

export default About;