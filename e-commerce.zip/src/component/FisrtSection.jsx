import sponsorImg from '../component/asset/sponsored items.png'
const Firstsection = () => {
    return (
        <> 
            <section className='sponsored-items' >
                <h1>Sponsored items</h1>
                <div className='flex'>
                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div> 
                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div>  
                    
                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div>   
                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div>  

                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div>  

                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div> 

                     <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div> 
                    <div>
                    <a href="http://"> <img src={sponsorImg} alt="" /></a>
                        <p> Items Name</p>
                        <h1>₦Price</h1>
                    </div> 
                </div>

            </section>
        </>
    )
}

export default Firstsection;