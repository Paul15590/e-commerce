import cart from '../component/asset/cart.svg';

 const  Header = () => {
    return (
      <>
        <header >
            <section className="flex">
                <h4> <a href="/">PAUL</a></h4>
                <p> <a href="/"> Store <br /> Locator </a></p>
                <p> <a href="/"> Sell on  <br /> Our Store </a></p>
                <input type="search" name="search" placeholder="Search for product brand and categories " />
                <p> <a href="/Form"> Login/  <br /> Sign up </a></p>

                <div className='flex'>
                    <div className='flex '>
                        <a href="/cart"> <img src={cart} alt="" /></a>
                        <p> <a href="/cart"> My <br /> Cart</a> </p>
                    </div>
                    <div className='cart'>
                        <p>0</p>
                    </div>
                </div>
            </section>

            <nav >
                <ul className='flex'>
                    <li> <a href="/Categories"> All Categories </a></li>
                    <li> <a href="/Categories"> Computer and Accesories</a></li>
                    <li> <a href="/Categories"> Phone and Tablets</a></li>
                    <li> <a href="/Categories"> Electronics</a></li>
                    <li> <a href="/Categories"> Fashion </a></li>
                    <li> <a href="/Categories"> Home and Kitchen</a></li>
                    <li> <a href="/Categories"> Kids and Toy</a></li>
                    <li> <a href="/Categories">Other Categories </a></li>
                </ul>
            </nav>

        </header>
      </>
    )
 }

 export default Header;